var searchData=
[
  ['te_5fnota_43',['te_nota',['../class_estudiant.html#a81f265e635e1fe198867a5b594359e1b',1,'Estudiant']]]
];
