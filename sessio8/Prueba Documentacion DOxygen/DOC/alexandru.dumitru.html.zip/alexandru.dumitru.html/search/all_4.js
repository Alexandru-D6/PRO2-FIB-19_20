var searchData=
[
  ['main_13',['main',['../pro2_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'pro2.cc']]],
  ['mida_14',['mida',['../class_cjt__estudiants.html#a87c69704a0eff48a301cfff05e6dd587',1,'Cjt_estudiants']]],
  ['mida_5fmaxima_15',['mida_maxima',['../class_cjt__estudiants.html#a171fdff58b408ccbf647ab594b5eafa4',1,'Cjt_estudiants']]],
  ['mitjana_5festudiants_5famb_5fnota_16',['mitjana_estudiants_amb_nota',['../class_cjt__estudiants.html#a8c8099d5080864a677743e5e1d1bbdf8',1,'Cjt_estudiants']]],
  ['modificar_5fnota_17',['modificar_nota',['../class_estudiant.html#a5d5eded678c16a864f22477d401a56af',1,'Estudiant']]]
];
