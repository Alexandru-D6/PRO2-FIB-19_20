var searchData=
[
  ['cjt_5festudiants_29',['Cjt_estudiants',['../class_cjt__estudiants.html#a31ffe72cadcf58d82c8b9f6659c56e7a',1,'Cjt_estudiants']]],
  ['comp_30',['comp',['../class_estudiant.html#a5f19b7f7436e8c12a13159335040ae42',1,'Estudiant']]],
  ['consultar_5fdni_31',['consultar_DNI',['../class_estudiant.html#ad37108e53c6c0f1fcb5786e77e1902f5',1,'Estudiant']]],
  ['consultar_5fnota_32',['consultar_nota',['../class_estudiant.html#a21afbb59cddf87258d600df04ab95397',1,'Estudiant']]]
];
